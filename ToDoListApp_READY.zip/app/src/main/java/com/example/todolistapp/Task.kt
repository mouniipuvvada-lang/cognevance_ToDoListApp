package com.example.todolistapp

data class Task(
    val id: Int = 0,
    var title: String,
    var description: String
)
