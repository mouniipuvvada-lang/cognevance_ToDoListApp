package com.example.todolistapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "TodoDatabase.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_TASKS = "tasks"
        private const val COLUMN_ID = "id"
        private const val COLUMN_TITLE = "title"
        private const val COLUMN_DESCRIPTION = "description"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $TABLE_TASKS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_TITLE TEXT NOT NULL,
                $COLUMN_DESCRIPTION TEXT
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_TASKS")
        onCreate(db)
    }

    fun addTask(task: Task): Long {
        val values = ContentValues().apply {
            put(COLUMN_TITLE, task.title)
            put(COLUMN_DESCRIPTION, task.description)
        }
        return writableDatabase.use { db ->
            db.insert(TABLE_TASKS, null, values)
        }
    }

    fun getAllTasks(): ArrayList<Task> {
        val tasks = ArrayList<Task>()
        readableDatabase.use { db ->
            db.rawQuery(
                "SELECT * FROM $TABLE_TASKS ORDER BY $COLUMN_ID DESC",
                null
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    tasks.add(
                        Task(
                            id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                            title = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)),
                            description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)) ?: ""
                        )
                    )
                }
            }
        }
        return tasks
    }

    fun updateTask(task: Task): Int {
        val values = ContentValues().apply {
            put(COLUMN_TITLE, task.title)
            put(COLUMN_DESCRIPTION, task.description)
        }
        return writableDatabase.use { db ->
            db.update(TABLE_TASKS, values, "$COLUMN_ID = ?", arrayOf(task.id.toString()))
        }
    }

    fun deleteTask(id: Int): Int {
        return writableDatabase.use { db ->
            db.delete(TABLE_TASKS, "$COLUMN_ID = ?", arrayOf(id.toString()))
        }
    }
}
