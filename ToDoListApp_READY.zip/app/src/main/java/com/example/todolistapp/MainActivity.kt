package com.example.todolistapp

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var fabAddTask: FloatingActionButton
    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var taskAdapter: TaskAdapter
    private var taskList = ArrayList<Task>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        databaseHelper = DatabaseHelper(this)
        recyclerView = findViewById(R.id.recyclerViewTasks)
        fabAddTask = findViewById(R.id.fabAddTask)

        recyclerView.layoutManager = LinearLayoutManager(this)

        taskAdapter = TaskAdapter(
            taskList,
            onEditClick = ::showEditTaskDialog,
            onDeleteClick = ::showDeleteConfirmation
        )
        recyclerView.adapter = taskAdapter

        loadTasks()
        fabAddTask.setOnClickListener { showTaskDialog(null) }
    }

    private fun loadTasks() {
        taskList = databaseHelper.getAllTasks()
        taskAdapter.updateList(taskList)
    }

    private fun showTaskDialog(existingTask: Task?) {
        val dialogView = LayoutInflater.from(this)
            .inflate(R.layout.dialog_task, null)

        val titleEditText = dialogView.findViewById<EditText>(R.id.etTaskTitle)
        val descriptionEditText = dialogView.findViewById<EditText>(R.id.etTaskDescription)

        existingTask?.let {
            titleEditText.setText(it.title)
            descriptionEditText.setText(it.description)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (existingTask == null) "Add New Task" else "Edit Task")
            .setView(dialogView)
            .setNegativeButton("Cancel", null)
            .setPositiveButton(if (existingTask == null) "Add" else "Update", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val title = titleEditText.text.toString().trim()
                val description = descriptionEditText.text.toString().trim()

                if (title.isEmpty()) {
                    titleEditText.error = "Please enter a task title"
                    return@setOnClickListener
                }

                if (existingTask == null) {
                    val result = databaseHelper.addTask(Task(title = title, description = description))
                    if (result != -1L) {
                        toast("Task added successfully")
                        loadTasks()
                        dialog.dismiss()
                    } else {
                        toast("Failed to add task")
                    }
                } else {
                    existingTask.title = title
                    existingTask.description = description
                    val result = databaseHelper.updateTask(existingTask)
                    if (result > 0) {
                        toast("Task updated successfully")
                        loadTasks()
                        dialog.dismiss()
                    } else {
                        toast("Failed to update task")
                    }
                }
            }
        }

        dialog.show()
    }

    private fun showEditTaskDialog(task: Task) {
        showTaskDialog(task)
    }

    private fun showDeleteConfirmation(task: Task) {
        AlertDialog.Builder(this)
            .setTitle("Delete Task")
            .setMessage("Are you sure you want to delete \"${task.title}\"?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                val result = databaseHelper.deleteTask(task.id)
                if (result > 0) {
                    toast("Task deleted successfully")
                    loadTasks()
                } else {
                    toast("Failed to delete task")
                }
            }
            .show()
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
